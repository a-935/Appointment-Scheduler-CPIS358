'use strict';

// Storage layer. Uses Node's built-in SQLite (node:sqlite, Node >= 22.5),
// so there are no native dependencies to compile.
const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const fs = require('node:fs');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data.sqlite');

// Ensure the directory exists (useful when DB_PATH points elsewhere).
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new DatabaseSync(DB_PATH);

// Pragmas for integrity and sane concurrency.
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

// ---- Schema ---------------------------------------------------------------
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT    NOT NULL,
    email         TEXT    NOT NULL UNIQUE,
    password_hash TEXT    NOT NULL,
    created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS services (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT    NOT NULL UNIQUE,
    description  TEXT    NOT NULL DEFAULT '',
    price        REAL    NOT NULL,
    duration_min INTEGER NOT NULL DEFAULT 30
  );

  CREATE TABLE IF NOT EXISTS appointments (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL,
    service_id  INTEGER NOT NULL,
    date        TEXT    NOT NULL,                 -- YYYY-MM-DD
    time        TEXT    NOT NULL,                 -- HH:MM
    status      TEXT    NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','confirmed','cancelled')),
    notes       TEXT    NOT NULL DEFAULT '',
    created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id),
    -- A user cannot hold two appointments in the same slot.
    UNIQUE (user_id, date, time)
  );

  CREATE INDEX IF NOT EXISTS idx_appts_user ON appointments(user_id);
  CREATE INDEX IF NOT EXISTS idx_appts_date ON appointments(date);
`);

// ---- Seed services once ---------------------------------------------------
const serviceCount = db.prepare('SELECT COUNT(*) AS n FROM services').get().n;
if (serviceCount === 0) {
  const insert = db.prepare(
    'INSERT INTO services (name, description, price, duration_min) VALUES (?, ?, ?, ?)'
  );
  const seed = [
    ['Consultation', 'A focused 30-minute consultation to discuss your needs.', 50, 30],
    ['Extended Consultation', 'A deeper 60-minute session for complex topics.', 75, 60],
    ['Follow-up', 'A 20-minute follow-up on a previous appointment.', 30, 20],
    ['Customer Support', 'Hands-on help resolving an issue, up to 45 minutes.', 40, 45],
  ];
  for (const row of seed) insert.run(...row);
}

module.exports = db;
