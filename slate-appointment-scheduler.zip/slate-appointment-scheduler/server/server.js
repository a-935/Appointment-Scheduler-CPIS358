'use strict';

const path = require('node:path');
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const TOKEN_TTL = '7d';

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// ---- Helpers --------------------------------------------------------------
function sign(user) {
  return jwt.sign({ sub: user.id, email: user.email }, JWT_SECRET, { expiresIn: TOKEN_TTL });
}

function publicUser(u) {
  return { id: u.id, name: u.name, email: u.email, created_at: u.created_at };
}

// Auth middleware: requires a valid Bearer token.
function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Sign in to continue.' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.sub);
    if (!user) return res.status(401).json({ error: 'Your session is no longer valid.' });
    req.user = user;
    next();
  } catch {
    return res.status(401).json({ error: 'Your session has expired. Sign in again.' });
  }
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;

// Password policy: >= 8 chars, at least one upper, one lower, one digit.
function passwordProblem(pw) {
  if (typeof pw !== 'string' || pw.length < 8) return 'Password must be at least 8 characters.';
  if (!/[A-Z]/.test(pw)) return 'Password needs at least one uppercase letter.';
  if (!/[a-z]/.test(pw)) return 'Password needs at least one lowercase letter.';
  if (!/\d/.test(pw)) return 'Password needs at least one number.';
  return null;
}

function isPast(date, time) {
  const when = new Date(`${date}T${time}:00`);
  return Number.isNaN(when.getTime()) || when.getTime() < Date.now();
}

// =====================  AUTH  =====================
app.post('/api/auth/register', (req, res) => {
  const name = (req.body.name || '').trim();
  const email = (req.body.email || '').trim().toLowerCase();
  const password = req.body.password || '';

  if (!name) return res.status(400).json({ error: 'Name is required.' });
  if (!EMAIL_RE.test(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
  const pwErr = passwordProblem(password);
  if (pwErr) return res.status(400).json({ error: pwErr });

  const exists = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (exists) return res.status(409).json({ error: 'An account with this email already exists.' });

  const hash = bcrypt.hashSync(password, 10);
  const info = db
    .prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)')
    .run(name, email, hash);
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);

  res.status(201).json({ token: sign(user), user: publicUser(user) });
});

app.post('/api/auth/login', (req, res) => {
  const email = (req.body.email || '').trim().toLowerCase();
  const password = req.body.password || '';
  if (!email || !password) return res.status(400).json({ error: 'Email and password are required.' });

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  // Same message for unknown email / wrong password (avoids account enumeration).
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Email or password is incorrect.' });
  }
  res.json({ token: sign(user), user: publicUser(user) });
});

app.get('/api/auth/me', auth, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

// =====================  SERVICES  =====================
app.get('/api/services', (_req, res) => {
  res.json(db.prepare('SELECT * FROM services ORDER BY price').all());
});

// Average price across services — replaces the old "average price" function.
app.get('/api/stats', auth, (req, res) => {
  const avg = db.prepare('SELECT ROUND(AVG(price), 2) AS avg FROM services').get().avg;
  const counts = db
    .prepare(
      `SELECT status, COUNT(*) AS n FROM appointments WHERE user_id = ? GROUP BY status`
    )
    .all(req.user.id);
  const byStatus = { pending: 0, confirmed: 0, cancelled: 0 };
  for (const c of counts) byStatus[c.status] = c.n;
  const total = byStatus.pending + byStatus.confirmed + byStatus.cancelled;
  res.json({ averageServicePrice: avg, total, byStatus });
});

// =====================  APPOINTMENTS  =====================
// Joined row including the service name/price for convenience.
const APPT_SELECT = `
  SELECT a.id, a.date, a.time, a.status, a.notes, a.created_at,
         s.id AS service_id, s.name AS service, s.price AS price, s.duration_min
  FROM appointments a
  JOIN services s ON s.id = a.service_id
`;

// List the current user's appointments, with optional filters.
app.get('/api/appointments', auth, (req, res) => {
  const clauses = ['a.user_id = ?'];
  const params = [req.user.id];

  if (req.query.status && ['pending', 'confirmed', 'cancelled'].includes(req.query.status)) {
    clauses.push('a.status = ?');
    params.push(req.query.status);
  }
  if (req.query.q) {
    clauses.push('(s.name LIKE ? OR a.notes LIKE ?)');
    const like = `%${req.query.q}%`;
    params.push(like, like);
  }
  if (req.query.from && DATE_RE.test(req.query.from)) {
    clauses.push('a.date >= ?');
    params.push(req.query.from);
  }
  if (req.query.to && DATE_RE.test(req.query.to)) {
    clauses.push('a.date <= ?');
    params.push(req.query.to);
  }

  const sql = `${APPT_SELECT} WHERE ${clauses.join(' AND ')} ORDER BY a.date, a.time`;
  res.json(db.prepare(sql).all(...params));
});

app.get('/api/appointments/:id', auth, (req, res) => {
  const row = db
    .prepare(`${APPT_SELECT} WHERE a.id = ? AND a.user_id = ?`)
    .get(req.params.id, req.user.id);
  if (!row) return res.status(404).json({ error: 'Appointment not found.' });
  res.json(row);
});

function validateApptInput(body) {
  const serviceId = Number(body.serviceId);
  const date = (body.date || '').trim();
  const time = (body.time || '').trim();
  const notes = (body.notes || '').trim();

  if (!serviceId) return { error: 'Choose a service.' };
  const service = db.prepare('SELECT id FROM services WHERE id = ?').get(serviceId);
  if (!service) return { error: 'That service does not exist.' };
  if (!DATE_RE.test(date)) return { error: 'Enter a valid date.' };
  if (!TIME_RE.test(time)) return { error: 'Enter a valid time.' };
  if (isPast(date, time)) return { error: 'Pick a date and time in the future.' };
  if (notes.length > 500) return { error: 'Notes are limited to 500 characters.' };

  return { value: { serviceId, date, time, notes } };
}

app.post('/api/appointments', auth, (req, res) => {
  const { error, value } = validateApptInput(req.body);
  if (error) return res.status(400).json({ error });

  try {
    const info = db
      .prepare(
        `INSERT INTO appointments (user_id, service_id, date, time, notes)
         VALUES (?, ?, ?, ?, ?)`
      )
      .run(req.user.id, value.serviceId, value.date, value.time, value.notes);
    const row = db.prepare(`${APPT_SELECT} WHERE a.id = ?`).get(info.lastInsertRowid);
    res.status(201).json(row);
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) {
      return res.status(409).json({ error: 'You already have an appointment in that slot.' });
    }
    throw e;
  }
});

app.put('/api/appointments/:id', auth, (req, res) => {
  const existing = db
    .prepare('SELECT * FROM appointments WHERE id = ? AND user_id = ?')
    .get(req.params.id, req.user.id);
  if (!existing) return res.status(404).json({ error: 'Appointment not found.' });

  const { error, value } = validateApptInput(req.body);
  if (error) return res.status(400).json({ error });

  try {
    db.prepare(
      `UPDATE appointments SET service_id = ?, date = ?, time = ?, notes = ? WHERE id = ?`
    ).run(value.serviceId, value.date, value.time, value.notes, existing.id);
    const row = db.prepare(`${APPT_SELECT} WHERE a.id = ?`).get(existing.id);
    res.json(row);
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) {
      return res.status(409).json({ error: 'You already have an appointment in that slot.' });
    }
    throw e;
  }
});

// Change only the status (confirm / cancel / reopen).
app.patch('/api/appointments/:id/status', auth, (req, res) => {
  const status = req.body.status;
  if (!['pending', 'confirmed', 'cancelled'].includes(status)) {
    return res.status(400).json({ error: 'Status must be pending, confirmed, or cancelled.' });
  }
  const info = db
    .prepare('UPDATE appointments SET status = ? WHERE id = ? AND user_id = ?')
    .run(status, req.params.id, req.user.id);
  if (info.changes === 0) return res.status(404).json({ error: 'Appointment not found.' });
  res.json(db.prepare(`${APPT_SELECT} WHERE a.id = ?`).get(req.params.id));
});

app.delete('/api/appointments/:id', auth, (req, res) => {
  const info = db
    .prepare('DELETE FROM appointments WHERE id = ? AND user_id = ?')
    .run(req.params.id, req.user.id);
  if (info.changes === 0) return res.status(404).json({ error: 'Appointment not found.' });
  res.status(204).end();
});

// SPA-style fallback for unknown non-API routes -> serve home.
app.get(/^(?!\/api).*/, (_req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

if (require.main === module) {
  app.listen(PORT, () => console.log(`Appointment Scheduler running at http://localhost:${PORT}`));
}

module.exports = app;
