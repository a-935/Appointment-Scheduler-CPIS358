/* Shared client helpers: API calls, auth token, nav state, toasts. */
(function () {
  const TOKEN_KEY = 'as_token';
  const USER_KEY = 'as_user';

  const Auth = {
    get token() { return localStorage.getItem(TOKEN_KEY); },
    get user() { try { return JSON.parse(localStorage.getItem(USER_KEY)); } catch { return null; } },
    set(token, user) { localStorage.setItem(TOKEN_KEY, token); localStorage.setItem(USER_KEY, JSON.stringify(user)); },
    clear() { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(USER_KEY); },
    get isLoggedIn() { return !!this.token; },
  };

  async function api(path, { method = 'GET', body, auth = true } = {}) {
    const headers = { 'Content-Type': 'application/json' };
    if (auth && Auth.token) headers.Authorization = `Bearer ${Auth.token}`;
    const res = await fetch(`/api${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
    if (res.status === 401 && auth) {
      Auth.clear();
      if (!location.pathname.endsWith('login.html')) location.href = '/login.html';
    }
    let data = null;
    if (res.status !== 204) { try { data = await res.json(); } catch { /* no body */ } }
    if (!res.ok) throw new Error((data && data.error) || 'Something went wrong.');
    return data;
  }

  function toast(msg) {
    let el = document.querySelector('.toast');
    if (!el) { el = document.createElement('div'); el.className = 'toast'; document.body.appendChild(el); }
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.remove('show'), 2400);
  }

  function showAlert(id, msg, type = 'error') {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = msg;
    el.className = `alert ${type} show`;
  }
  function hideAlert(id) {
    const el = document.getElementById(id);
    if (el) el.className = 'alert';
  }

  // Render the shared top bar into <div id="topbar"></div>.
  function renderNav(active) {
    const loggedIn = Auth.isLoggedIn;
    const links = loggedIn
      ? [
          ['/', 'Home', 'home'],
          ['/book.html', 'Book', 'book'],
          ['/dashboard.html', 'My appointments', 'dashboard'],
          ['/about.html', 'About', 'about'],
        ]
      : [
          ['/', 'Home', 'home'],
          ['/about.html', 'About', 'about'],
        ];

    const right = loggedIn
      ? `<a href="/dashboard.html" class="${active === 'dashboard' ? 'active' : ''}">${escapeHtml(Auth.user?.name || 'Account')}</a>
         <a href="#" id="signout" class="btn btn-ghost btn-sm">Sign out</a>`
      : `<a href="/login.html" class="${active === 'login' ? 'active' : ''}">Log in</a>
         <a href="/signup.html" class="btn btn-primary btn-sm">Create account</a>`;

    const navLinks = links
      .map(([href, label, key]) => `<a href="${href}" class="${active === key ? 'active' : ''}">${label}</a>`)
      .join('');

    const host = document.getElementById('topbar');
    if (!host) return;
    host.innerHTML = `
      <header class="topbar">
        <div class="container">
          <a class="brand" href="/"><span class="mark"></span> Slate</a>
          <button class="nav-toggle" aria-label="Menu" id="navToggle">☰</button>
          <nav class="nav" id="navMenu">${navLinks}${right}</nav>
        </div>
      </header>`;

    const toggle = document.getElementById('navToggle');
    const menu = document.getElementById('navMenu');
    toggle?.addEventListener('click', () => menu.classList.toggle('open'));
    document.getElementById('signout')?.addEventListener('click', (e) => {
      e.preventDefault();
      Auth.clear();
      location.href = '/';
    });
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function requireAuth() {
    if (!Auth.isLoggedIn) { location.href = '/login.html'; return false; }
    return true;
  }

  window.App = { Auth, api, toast, showAlert, hideAlert, renderNav, escapeHtml, requireAuth };
})();
