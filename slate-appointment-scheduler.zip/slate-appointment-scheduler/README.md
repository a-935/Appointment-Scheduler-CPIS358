# Slate — Appointment Scheduler

A clean, full-stack appointment-booking web app: a REST API with JWT authentication and SQLite storage, plus a no-framework HTML/CSS/JS front-end. Users can register, log in, browse services, book appointments, and manage them (search, filter, confirm, cancel, edit, delete) from a single dashboard.

This is a ground-up rebuild of a CPIS-358 (Internet Application and Web Programming) course project. See **Design notes** below for what changed and why.

## Features

- **Accounts** — register and log in. Passwords are hashed with bcrypt; sessions use signed JWTs.
- **Services & pricing** — seeded catalogue served from the API, with an average-price summary.
- **Booking** — pick a service, date, and time. Past slots and double-bookings are rejected server-side.
- **Dashboard** — list, search, and filter your appointments; confirm, cancel, edit, or delete them.
- **Isolation** — every endpoint scopes data to the signed-in user; you only ever see your own appointments.

## Tech stack

| Layer | Choice |
|-------|--------|
| Runtime | Node.js ≥ 22.5 |
| API | Express |
| Storage | SQLite via the built-in `node:sqlite` module (no native build step) |
| Auth | `bcryptjs` (hashing) + `jsonwebtoken` (sessions) |
| Front-end | Static HTML, CSS, and vanilla JS (no framework) |

## Getting started

```bash
npm install
npm start
# open http://localhost:3000
```

The database file (`server/data.sqlite`) is created and seeded automatically on first run.

Environment variables (all optional):

| Variable | Default | Purpose |
|----------|---------|---------|
| `PORT` | `3000` | HTTP port |
| `JWT_SECRET` | `dev-secret-change-me` | Token signing key — set a real value in production |
| `DB_PATH` | `server/data.sqlite` | SQLite file location |

## API reference

All `/api/appointments` and `/api/stats` routes require an `Authorization: Bearer <token>` header.

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/auth/register` | Create an account → `{ token, user }` |
| POST | `/api/auth/login` | Log in → `{ token, user }` |
| GET | `/api/auth/me` | Current user |
| GET | `/api/services` | List services (public) |
| GET | `/api/stats` | Average price + appointment counts by status |
| GET | `/api/appointments` | List own appointments. Query: `status`, `q`, `from`, `to` |
| POST | `/api/appointments` | Create `{ serviceId, date, time, notes }` |
| GET | `/api/appointments/:id` | Get one (own) |
| PUT | `/api/appointments/:id` | Update `{ serviceId, date, time, notes }` |
| PATCH | `/api/appointments/:id/status` | Set `{ status }` (pending/confirmed/cancelled) |
| DELETE | `/api/appointments/:id` | Delete (own) |

## Data model

```
users          (id, name, email UNIQUE, password_hash, created_at)
services       (id, name, description, price, duration_min)
appointments   (id, user_id FK→users, service_id FK→services,
                date, time, status, notes, created_at,
                UNIQUE(user_id, date, time))
```

## Project structure

```
.
├── server/
│   ├── server.js     # Express app + all API routes
│   └── db.js         # SQLite schema + seed
├── public/
│   ├── index.html    # Home (services + pricing)
│   ├── about.html
│   ├── login.html
│   ├── signup.html
│   ├── book.html     # Create / edit an appointment
│   ├── dashboard.html# Manage appointments
│   ├── css/styles.css
│   └── js/api.js     # Shared fetch client + auth + nav
└── package.json
```

## Design notes (rebuild)

The original ASP.NET MVC version had a number of issues this rebuild fixes:

- The `User` model used an integer **primary key named `date`** and stored the email in a field named `time`. Replaced with a proper `users` table.
- Appointments used the **appointment *type* as the primary key**, so only one appointment per type could ever exist, with no link to a user. Replaced with an `id`-keyed table tied to a user, service, date, time, and status.
- **Login performed no real authentication** — it only checked that fields were non-empty and redirected. Replaced with bcrypt verification and JWT sessions.
- **Passwords were stored in plain text.** Now hashed with bcrypt.
- `Home` and `Account` controllers **duplicated each other** (two login/schedule flows). Consolidated into one API.
- Views shipped **broken asset paths and missing images**, duplicated inline styles, and full `<html>` documents inside a layout. Rebuilt as a single consistent design system.
- A leftover **"Books" search action echoed user input straight back** (reflected). Replaced with parameterised search over the user's own data.

## License

MIT — coursework rebuild, free to reuse.
